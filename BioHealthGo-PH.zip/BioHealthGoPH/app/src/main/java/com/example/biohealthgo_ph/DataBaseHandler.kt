package com.example.biohealthgo_ph

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import android.view.accessibility.AccessibilityManager
import android.widget.Toast
import androidx.core.content.contentValuesOf

val DATABASE_NAME = "MyDB"
val TABLE_NAME = "Users"
val COL_USERNAME = "Names"
val COL_EMAIL = "Emails"
val COL_PASSWORD = "Passwords"
val COL_RETYPEPASSORD = "Retype-Passwords"

class DataBaseHandler(var context: Context) : SQLiteOpenHelper(context, DATABASE_NAME,null,1) {
    override fun onCreate(db: SQLiteDatabase?) {
        val createTable = "CREATE TABLE" + TABLE_NAME + " (" +
                COL_USERNAME + "VARCHAR(256)," +
                COL_EMAIL + "VARCHAR(256)," +
                COL_PASSWORD + "VARCHAR(256)," +
                COL_RETYPEPASSORD + "VARCHAR(256),";

        db?.execSQL(createTable)

    }

    override fun onUpgrade(db: SQLiteDatabase?, oldVersion: Int, newVersion: Int) {
        TODO("Not yet implemented")
    }

    fun insertData(user: User){
        val db = this.writableDatabase
        var cv = ContentValues()
        cv.put(COL_USERNAME,user.username)
        cv.put(COL_EMAIL,user.email)
        cv.put(COL_PASSWORD,user.password)
        cv.put(COL_RETYPEPASSORD,user.retypepassword)

        var result = db.insert(TABLE_NAME,null,cv)
        if(result == -1.toLong())
            Toast.makeText(context,"Failed",Toast.LENGTH_SHORT).show()
        else
            Toast.makeText(context,"Success",Toast.LENGTH_SHORT).show()
    }
}
