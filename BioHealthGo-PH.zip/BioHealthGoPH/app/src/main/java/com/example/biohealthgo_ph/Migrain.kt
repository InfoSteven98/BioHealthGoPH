package com.example.biohealthgo_ph

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class Migrain : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_migrain)
    }
}