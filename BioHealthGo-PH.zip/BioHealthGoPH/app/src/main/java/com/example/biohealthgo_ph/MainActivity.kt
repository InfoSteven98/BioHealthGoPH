package com.example.biohealthgo_ph

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val username = findViewById<EditText>(R.id.Email_Login)
        val email = findViewById<EditText>(R.id.UserEmail)
        val password = findViewById<EditText>(R.id.UserPasswordLogin)
        val retypepassword = findViewById<EditText>(R.id.UserPasswordVerify)
        val btnLogin = findViewById<Button>(R.id.SignUpButton)
        val backSignIn = findViewById<TextView>(R.id.SignInPage)

        if(username.text.toString().equals("admin")&&
            password.text.toString().equals("admin")&&
            email.text.toString().equals("admin@gmail.com")&&
            retypepassword.text.toString().equals("admin")){
            val intent = Intent (this, LoginPage::class.java)
            startActivity(intent)
        }

        btnLogin.setOnClickListener{
            val intent = Intent(this, LoginPage::class.java)
            startActivity(intent)
        }

        backSignIn.setOnClickListener{
            val intent = Intent(this, LoginPage::class.java)
            startActivity(intent)
        }

    }
}

/*            if(username.text.toString().equals("admin")&&
                    password.text.toString().equals("admin")&&
                    email.text.toString().equals("admin@gmail.com")&&
                    retypepassword.text.toString().equals("admin")){
                val intent = Intent (this, LoginPage::class.java)
                startActivity(intent)
            }
 */
/*
        val context = this

        btnLogin.setOnClickListener{
            if(username.text.toString().length > 0 &&
                email.text.toString().length > 0 &&
                password.text.toString().length > 0 &&
                retypepassword.text.toString().length > 0){

                var user = User(username.text.toString(),
                    email.text.toString(),
                    password.text.toString(),
                    retypepassword.text.toString())

                var db = DataBaseHandler(context)
                db.insertData(user)
            }else{
                Toast.makeText(context,"Please fill the registration forum",Toast.LENGTH_SHORT).show()
            }
        }
 */