package com.example.biohealthgo_ph

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class BloodPreassure : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_bloodpressure)
    }
}