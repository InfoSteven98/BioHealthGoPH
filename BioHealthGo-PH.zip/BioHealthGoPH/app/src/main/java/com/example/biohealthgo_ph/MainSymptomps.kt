package com.example.biohealthgo_ph

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button

class MainSymptomps : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main_symptomps)

        val btnMainMenu = findViewById<Button>(R.id.MainMenu)
        val btnBloodPreassure = findViewById<Button>(R.id.BloodPreassure)
        val btnHeadAche = findViewById<Button>(R.id.HeadAche)
        val btnMigrain = findViewById<Button>(R.id.Migrain)
        val btnMildCold = findViewById<Button>(R.id.MildCold)
        val btnSoreThroat = findViewById<Button>(R.id.SoreThroat)
        val btnStomachAche = findViewById<Button>(R.id.StomachAche)
        val btnTension = findViewById<Button>(R.id.Tension)

        btnMainMenu.setOnClickListener {
            val intent = Intent(this, HomePage::class.java)
            startActivity(intent)
        }
        btnBloodPreassure.setOnClickListener {
            val intent = Intent(this, BloodPreassure::class.java)
            startActivity(intent)
        }
        btnHeadAche.setOnClickListener {
            val intent = Intent(this, HeadAche::class.java)
            startActivity(intent)
        }
        btnMigrain.setOnClickListener {
            val intent = Intent(this, Migrain::class.java)
            startActivity(intent)
        }
        btnMildCold.setOnClickListener {
            val intent = Intent(this, MildCold::class.java)
            startActivity(intent)
        }
        btnSoreThroat.setOnClickListener {
            val intent = Intent(this, SoreThroat::class.java)
            startActivity(intent)
        }
        btnStomachAche.setOnClickListener {
            val intent = Intent(this, StomachAche::class.java)
            startActivity(intent)
        }
        btnTension.setOnClickListener {
            val intent = Intent(this, Tension::class.java)
            startActivity(intent)
        }
    }
}