package com.example.biohealthgo_ph

class User {

    var username : String = ""
    var email : String = ""
    var password : String = ""
    var retypepassword : String = ""

    constructor(username:String, email:String, password:String, retypepassword:String){
        this.username = username
        this.email = email
        this.password = password
        this.retypepassword = retypepassword
    }
}