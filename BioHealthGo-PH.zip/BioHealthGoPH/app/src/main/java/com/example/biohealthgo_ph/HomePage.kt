package com.example.biohealthgo_ph

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button

class HomePage : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_home_page)

        val feeling = findViewById<Button>(R.id.btn_Feel)
        val about = findViewById<Button>(R.id.ButtonAbout)
        val diary = findViewById<Button>(R.id.btn_Diary)

        feeling.setOnClickListener {
            val intent = Intent(this, MainSymptomps::class.java)
            startActivity(intent)
        }

        about.setOnClickListener {
            val intent = Intent(this,DoctorContact::class.java)
            startActivity(intent)
        }

        diary.setOnClickListener {
            val intent = Intent(this, UserDiary::class.java)
            startActivity(intent)
        }
    }
}