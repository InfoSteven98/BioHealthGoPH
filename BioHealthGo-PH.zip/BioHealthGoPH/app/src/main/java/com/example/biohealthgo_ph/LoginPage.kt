package com.example.biohealthgo_ph

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView

class LoginPage : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login_page)

        val loginemail = findViewById<EditText>(R.id.Email_Login)
        val loginpassword = findViewById<EditText>(R.id.UserPasswordLogin)
        val backSignUp = findViewById<TextView>(R.id.SignUpPage)
        val btnHomePage = findViewById<Button>(R.id.Login)

        btnHomePage.setOnClickListener{
            if(loginemail.text.toString().equals("admin")&&
                    loginpassword.text.toString().equals("admin")){
                val intent = Intent(this, HomePage::class.java)

                startActivity(intent)
            }
        }
        backSignUp.setOnClickListener{
            val intent = Intent(this, MainActivity::class.java)
            startActivity(intent)
        }
    }
}